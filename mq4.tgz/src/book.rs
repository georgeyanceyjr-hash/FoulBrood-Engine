//! Opening book: position key -> weighted candidate moves (stored as UHP strings).
//! Loaded from `thoraxrex-book.txt` next to the executable (or $TR_BOOK).
//! Line format: `<key hex> <weight> <move string>`.

use crate::board::*;
use std::collections::HashMap;
use std::sync::OnceLock;

type Book = HashMap<u64, Vec<(u32, String)>>;

fn book() -> &'static Book {
    static B: OnceLock<Book> = OnceLock::new();
    B.get_or_init(|| {
        let path = std::env::var("TR_BOOK").ok().map(std::path::PathBuf::from).or_else(|| {
            std::env::current_exe().ok().and_then(|p| p.parent().map(|d| d.join("thoraxrex-book.txt")))
        });
        let mut m: Book = HashMap::new();
        if let Some(p) = path {
            if let Ok(text) = std::fs::read_to_string(p) {
                for line in text.lines() {
                    let mut it = line.splitn(3, ' ');
                    let (Some(k), Some(w), Some(mv)) = (it.next(), it.next(), it.next()) else { continue };
                    let (Ok(k), Ok(w)) = (u64::from_str_radix(k, 16), w.parse::<u32>()) else { continue };
                    m.entry(k).or_default().push((w, mv.to_string()));
                }
            }
        }
        m
    })
}

fn rand_u32() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let n = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.subsec_nanos()).unwrap_or(7);
    let mut x = n ^ 0x9E37_79B9;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    x
}

/// Pick a weighted book move for the current position, if any (validated legal).
pub fn probe(b: &mut Board) -> Option<Move> {
    let entries = book().get(&b.book_key())?;
    let total: u32 = entries.iter().map(|e| e.0).sum();
    if total == 0 {
        return None;
    }
    let mut r = rand_u32() % total;
    let mut pick = &entries[0].1;
    for (w, mv) in entries {
        if r < *w {
            pick = mv;
            break;
        }
        r -= w;
    }
    b.parse_move(pick).ok()
}
