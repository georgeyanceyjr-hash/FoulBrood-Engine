//! Self-play data generation: `thoraxrex datagen <games> <depth> <seed> <out.jsonl>`.
//! Each game starts with 4-8 random plies, then both sides play a fixed-depth search.
//! Writes one JSON line per game: moves, per-ply search scores (side to move), result.
use crate::board::*;
use crate::search::{Limits, Searcher};
use std::io::Write;

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
}

pub fn run(args: &[String]) {
    let games: usize = args.get(0).and_then(|s| s.parse().ok()).unwrap_or(10);
    let depth: u32 = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(5);
    let seed: u64 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(1);
    let out = args.get(3).cloned().unwrap_or_else(|| "datagen.jsonl".into());
    let gt = GameType::parse("Base+MLP").unwrap();
    let mut f = std::fs::OpenOptions::new().create(true).append(true).open(&out).expect("open output");
    let mut rng = Rng(seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1);
    let mut searcher = Searcher::new(32);
    let mut legal = Vec::new();
    for _ in 0..games {
        let mut b = Board::new(gt);
        let nrand = 4 + (rng.next() % 5) as u32;
        let mut moves: Vec<String> = Vec::new();
        let mut scores: Vec<String> = Vec::new();
        let mut ply = 0u32;
        while b.result() == 0 && b.repetitions() < 2 && ply < 300 {
            legal.clear();
            b.legal_moves(&mut legal);
            if legal.is_empty() {
                break;
            }
            let m = if ply < nrand {
                legal[(rng.next() % legal.len() as u64) as usize]
            } else {
                let res = searcher.search(&b, Limits { time: None, depth: Some(depth) }, 1, |_, _, _| {});
                scores.push(format!("[{},{}]", ply, res.score));
                res.best
            };
            moves.push(b.move_to_string(m));
            b.make(m);
            ply += 1;
        }
        let r = match b.result() {
            1 => "1",
            2 => "0",
            _ => "0.5",
        };
        let mv_json: Vec<String> = moves.iter().map(|m| format!("\"{}\"", m.replace('\\', "\\\\"))).collect();
        let _ = writeln!(f, "{{\"gt\":\"Base+MLP\",\"moves\":[{}],\"scores\":[{}],\"result\":{}}}", mv_json.join(","), scores.join(","), r);
    }
}
