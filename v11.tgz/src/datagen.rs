//! Self-play data generation: `thoraxrex datagen <games> <depth> <seed> <out.jsonl>`.
//! Each game starts with 4-8 random plies, then both sides play a fixed-depth search.
//! Writes one JSON line per game: moves, per-ply search scores (side to move), result.
use crate::board::*;
use crate::search::{Limits, Searcher};
use std::io::Write;

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
}

pub fn run(args: &[String]) {
    let games: usize = args.get(0).and_then(|s| s.parse().ok()).unwrap_or(10);
    let depth: u32 = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(5);
    let seed: u64 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(1);
    let out = args.get(3).cloned().unwrap_or_else(|| "datagen.jsonl".into());
    let gt = GameType::parse("Base+MLP").unwrap();
    let mut f = std::fs::OpenOptions::new().create(true).append(true).open(&out).expect("open output");
    let mut rng = Rng(seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1);
    let mut searcher = Searcher::new(32);
    let mut legal = Vec::new();
    for _ in 0..games {
        let mut b = Board::new(gt);
        let nrand = 4 + (rng.next() % 5) as u32;
        let mut moves: Vec<String> = Vec::new();
        let mut scores: Vec<String> = Vec::new();
        let mut ply = 0u32;
        while b.result() == 0 && b.repetitions() < 2 && ply < 300 {
            legal.clear();
            b.legal_moves(&mut legal);
            if legal.is_empty() {
                break;
            }
            let m = if ply < nrand {
                legal[(rng.next() % legal.len() as u64) as usize]
            } else {
                let res = searcher.search(&b, Limits { time: None, depth: Some(depth) }, 1, |_, _, _| {});
                scores.push(format!("[{},{}]", ply, res.score));
                res.best
            };
            moves.push(b.move_to_string(m));
            b.make(m);
            ply += 1;
        }
        let r = match b.result() {
            1 => "1",
            2 => "0",
            _ => "0.5",
        };
        let mv_json: Vec<String> = moves.iter().map(|m| format!("\"{}\"", m.replace('\\', "\\\\"))).collect();
        let _ = writeln!(f, "{{\"gt\":\"Base+MLP\",\"moves\":[{}],\"scores\":[{}],\"result\":{}}}", mv_json.join(","), scores.join(","), r);
    }
}

/// `thoraxrex dumpfeat <in.jsonl> <out.csv>`: replay games and write one row per position:
/// side-to-move features (NF), opponent features (NF), search score for side to move (or empty), result for side to move.
pub fn dumpfeat(args: &[String]) {
    use std::io::BufRead;
    let inp = args.get(0).expect("input");
    let out = args.get(1).expect("output");
    let r = std::io::BufReader::new(std::fs::File::open(inp).expect("open input"));
    let mut f = std::io::BufWriter::new(std::fs::File::create(out).expect("create output"));
    let gt = GameType::parse("Base+MLP").unwrap();
    let mut ngames = 0;
    for line in r.lines() {
        let Ok(line) = line else { continue };
        let moves = json_str_array(&line, "\"moves\"");
        let scores = json_pairs(&line, "\"scores\"");
        let result: f64 = json_num(&line, "\"result\"").unwrap_or(0.5);
        let mut b = Board::new(gt);
        let mut ok = true;
        for (ply, mv) in moves.iter().enumerate() {
            if b.result() != 0 {
                break;
            }
            if ply >= 4 {
                let fb = crate::eval::features_both(&mut b);
                let me = b.side() as usize;
                let sc = scores.iter().find(|p| p.0 == ply as i64).map(|p| p.1.to_string()).unwrap_or_default();
                let res = if me == 0 { result } else { 1.0 - result };
                let mut row = String::with_capacity(512);
                for v in fb[me].iter().chain(fb[1 - me].iter()) {
                    row.push_str(&v.to_string());
                    row.push(',');
                }
                row.push_str(&sc);
                row.push(',');
                row.push_str(&format!("{}", res));
                let _ = writeln!(f, "{}", row);
            }
            match b.parse_move(mv) {
                Ok(m) => {
                    b.make(m);
                }
                Err(_) => {
                    ok = false;
                    break;
                }
            }
        }
        if ok {
            ngames += 1;
        }
    }
    eprintln!("dumpfeat: {} games", ngames);
}

fn after_key<'a>(s: &'a str, key: &str, open: char) -> Option<&'a str> {
    let i = s.find(key)?;
    let rest = &s[i + key.len()..];
    let j = rest.find(open)?;
    Some(&rest[j + 1..])
}

fn json_str_array(s: &str, key: &str) -> Vec<String> {
    let Some(rest) = after_key(s, key, '[') else { return vec![] };
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut in_str = false;
    let mut esc = false;
    for ch in rest.chars() {
        if in_str {
            if esc {
                cur.push(ch);
                esc = false;
            } else if ch == '\\' {
                esc = true;
            } else if ch == '"' {
                in_str = false;
                out.push(std::mem::take(&mut cur));
            } else {
                cur.push(ch);
            }
        } else if ch == '"' {
            in_str = true;
        } else if ch == ']' {
            break;
        }
    }
    out
}

fn json_pairs(s: &str, key: &str) -> Vec<(i64, i64)> {
    let Some(rest) = after_key(s, key, '[') else { return vec![] };
    let rest = rest.trim_start();
    if rest.starts_with(']') {
        return vec![];
    }
    let end = rest.find("]]").map(|e| e + 1).unwrap_or(0);
    let body = &rest[..end];
    body.split("],[")
        .filter_map(|p| {
            let p = p.trim_matches(|c| c == '[' || c == ']');
            let mut it = p.split(',');
            Some((it.next()?.trim().parse().ok()?, it.next()?.trim().parse().ok()?))
        })
        .collect()
}

fn json_num(s: &str, key: &str) -> Option<f64> {
    let rest = after_key(s, key, ':')?;
    let end = rest.find(|c: char| c == ',' || c == '}').unwrap_or(rest.len());
    rest[..end].trim().parse().ok()
}
