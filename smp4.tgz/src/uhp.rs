use crate::board::*;
use crate::search::{report_score, Limits, Searcher};
use std::time::Duration;

pub const NAME: &str = "ThoraxRex";
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

pub struct Engine {
    pub board: Board,
    pub moves: Vec<String>,
    pub undos: Vec<Undo>,
    pub started: bool,
    pub searcher: Searcher,
    pub report: bool,
    pub threads: usize,
    pub hash_mb: usize,
    pub use_book: bool,
}

impl Engine {
    pub fn new() -> Engine {
        let threads = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1).min(8);
        Engine {
            board: Board::new(GameType::default()),
            moves: Vec::new(),
            undos: Vec::new(),
            started: false,
            searcher: Searcher::new(64),
            report: true,
            threads,
            hash_mb: 64,
            use_book: true,
        }
    }

    pub fn info() -> Vec<String> {
        vec![format!("id {} v{}", NAME, VERSION), "Mosquito;Ladybug;Pillbug".into()]
    }

    fn state_string(&self) -> &'static str {
        if !self.started {
            return "NotStarted";
        }
        match self.board.result() {
            1 => "WhiteWins",
            2 => "BlackWins",
            3 => "Draw",
            _ => {
                if self.board.repetitions() >= 2 {
                    "Draw"
                } else if self.moves.is_empty() {
                    "NotStarted"
                } else {
                    "InProgress"
                }
            }
        }
    }

    pub fn game_over(&self) -> bool {
        // Repetition draws are reported in the GameString, but play is still accepted so a
        // viewer with slightly different repetition rules never gets stuck.
        self.started && self.board.result() != 0
    }

    pub fn game_string(&self) -> String {
        let side = if self.board.side() == 0 { "White" } else { "Black" };
        let turn = self.board.ply / 2 + 1;
        let mut s = format!("{};{};{}[{}]", self.board.gt.to_string(), self.state_string(), side, turn);
        for m in &self.moves {
            s.push(';');
            s.push_str(m);
        }
        s
    }

    pub fn execute(&mut self, line: &str) -> Vec<String> {
        let line = line.trim();
        let (cmd, args) = match line.find(' ') {
            Some(i) => (&line[..i], line[i + 1..].trim()),
            None => (line, ""),
        };
        match cmd {
            "" => vec![],
            "info" => Self::info(),
            "newgame" => self.newgame(args),
            "play" => self.play(args),
            "pass" => self.play("pass"),
            "validmoves" => self.validmoves(),
            "bestmove" => self.bestmove(args),
            "undo" => self.undo(args),
            "options" => self.options(args),
            "features" => {
                let f = crate::eval::features(&mut self.board);
                vec![f.iter().map(|x| x.to_string()).collect::<Vec<_>>().join(",")]
            }
            "key" => vec![format!("{:016x}", self.board.book_key())],
            "evaluate" => vec![crate::eval::evaluate(&mut self.board).to_string()],
            "perft" => match args.parse::<u32>() {
                Ok(d) => vec![self.board.perft(d).to_string()],
                Err(_) => vec!["err perft requires a depth.".into()],
            },
            _ => vec![format!("err Invalid command '{}'.", cmd)],
        }
    }

    fn newgame(&mut self, args: &str) -> Vec<String> {
        let fields: Vec<&str> = if args.is_empty() { vec!["Base"] } else { args.split(';').collect() };
        let gt = match GameType::parse(fields[0].trim()) {
            Some(g) => g,
            None => return vec![format!("err Invalid GameTypeString '{}'.", fields[0])],
        };
        let mut fresh = Engine {
            board: Board::new(gt),
            moves: Vec::new(),
            undos: Vec::new(),
            started: true,
            searcher: std::mem::replace(&mut self.searcher, Searcher::new(1)),
            report: self.report,
            threads: self.threads,
            hash_mb: self.hash_mb,
            use_book: self.use_book,
        };
        if fields.len() > 1 {
            if fields.len() < 3 {
                self.searcher = fresh.searcher;
                return vec!["err GameString must contain type, state and turn.".into()];
            }
            for mv in &fields[3..] {
                let r = fresh.play(mv.trim());
                if let Some(e) = r.first().filter(|s| s.starts_with("err") || s.starts_with("invalidmove")) {
                    let e = e.clone();
                    self.searcher = fresh.searcher;
                    return vec![format!("err Invalid GameString: {}", e)];
                }
            }
        }
        fresh.searcher.clear();
        *self = fresh;
        vec![self.game_string()]
    }

    fn play(&mut self, args: &str) -> Vec<String> {
        if !self.started {
            return vec!["err No game in progress. Try 'newgame' to start a new game.".into()];
        }
        if self.game_over() {
            return vec!["err The game is over.".into()];
        }
        match self.board.parse_move(args) {
            Ok(m) => {
                let text = self.board.move_to_string(m);
                let u = self.board.make(m);
                self.undos.push(u);
                self.moves.push(text);
                vec![self.game_string()]
            }
            Err(e) => vec![format!("invalidmove {}", e)],
        }
    }

    fn validmoves(&mut self) -> Vec<String> {
        if !self.started {
            return vec!["err No game in progress.".into()];
        }
        if self.game_over() {
            return vec![String::new()];
        }
        let mut v = Vec::new();
        self.board.legal_moves(&mut v);
        let strs: Vec<String> = v.iter().map(|&m| self.board.move_to_string(m)).collect();
        vec![strs.join(";")]
    }

    fn undo(&mut self, args: &str) -> Vec<String> {
        let n = if args.is_empty() {
            1
        } else {
            match args.parse::<usize>() {
                Ok(n) if n >= 1 => n,
                _ => return vec!["err undo requires a positive integer.".into()],
            }
        };
        if n > self.undos.len() {
            return vec![format!("err Cannot undo {} move(s).", n)];
        }
        for _ in 0..n {
            let u = self.undos.pop().unwrap();
            self.board.unmake(u);
            self.moves.pop();
        }
        vec![self.game_string()]
    }

    fn options(&mut self, args: &str) -> Vec<String> {
        let opt_line = |e: &Engine, name: &str| -> Option<String> {
            match name {
                "ReportFoulBroodScores" => Some(format!(
                    "ReportFoulBroodScores;bool;{};True",
                    if e.report { "True" } else { "False" }
                )),
                "Threads" => Some(format!("Threads;int;{};{};1;64", e.threads, e.threads)),
                "HashMB" => Some(format!("HashMB;int;{};64;1;4096", e.hash_mb)),
                "UseBook" => Some(format!("UseBook;bool;{};True", if e.use_book { "True" } else { "False" })),
                _ => None,
            }
        };
        let parts: Vec<&str> = args.split_whitespace().collect();
        match parts.as_slice() {
            [] => ["ReportFoulBroodScores", "Threads", "HashMB", "UseBook"]
                .iter()
                .filter_map(|n| opt_line(self, n))
                .collect(),
            ["get", name] => match opt_line(self, name) {
                Some(l) => vec![l],
                None => vec![format!("err Unknown option '{}'.", name)],
            },
            ["set", name, value] => {
                match *name {
                    "ReportFoulBroodScores" => match *value {
                        "True" => self.report = true,
                        "False" => self.report = false,
                        _ => return vec!["err ReportFoulBroodScores must be True or False.".into()],
                    },
                    "UseBook" => match *value {
                        "True" => self.use_book = true,
                        "False" => self.use_book = false,
                        _ => return vec!["err UseBook must be True or False.".into()],
                    },
                    "Threads" => match value.parse::<usize>() {
                        Ok(n) if (1..=64).contains(&n) => self.threads = n,
                        _ => return vec!["err Threads must be 1 to 64.".into()],
                    },
                    "HashMB" => match value.parse::<usize>() {
                        Ok(n) if (1..=4096).contains(&n) => {
                            self.hash_mb = n;
                            self.searcher = Searcher::new(n);
                        }
                        _ => return vec!["err HashMB must be 1 to 4096.".into()],
                    },
                    _ => return vec![format!("err Unknown option '{}'.", name)],
                }
                vec![opt_line(self, name).unwrap()]
            }
            _ => vec!["err Invalid options command.".into()],
        }
    }

    fn bestmove(&mut self, args: &str) -> Vec<String> {
        if !self.started {
            return vec!["err No game in progress.".into()];
        }
        if self.game_over() {
            return vec!["err The game is over.".into()];
        }
        if self.use_book {
            if let Some(m) = crate::book::probe(&mut self.board) {
                let text = self.board.move_to_string(m);
                if self.report {
                    eprintln!("FoulBroodScore v1;depth=1;score=0;move={}", text);
                    eprintln!("FoulBroodScore v2;kind=final;status=complete;depth=1;score=0;move={};evalmove={}", text, text);
                }
                return vec![text];
            }
        }
        let parts: Vec<&str> = args.split_whitespace().collect();
        let limits = match parts.as_slice() {
            ["time", t] => match parse_time(t) {
                Some(d) => Limits { time: Some(d), depth: None },
                None => return vec!["err Invalid time; use hh:mm:ss.".into()],
            },
            ["depth", d] => match d.parse::<u32>() {
                Ok(d) => Limits { time: None, depth: Some(d.clamp(1, 60)) },
                Err(_) => return vec!["err Invalid depth.".into()],
            },
            _ => return vec!["err bestmove requires 'time hh:mm:ss' or 'depth N'.".into()],
        };
        let report = self.report;
        let board = self.board.clone();
        let res = self.searcher.search(&board, limits, self.threads, |depth, score, mv| {
            let score = report_score(score);
            if report {
                let text = board.move_to_string(mv);
                eprintln!("FoulBroodScore v1;depth={};score={};move={}", depth, score, text);
                eprintln!("FoulBroodScore v2;kind=iteration;depth={};score={};move={}", depth, score, text);
            }
        });
        let text = self.board.move_to_string(res.best);
        eprintln!("info depth {} score {} nodes {} time_ms {} qnodes {}", res.depth, res.score, res.nodes, res.ms, crate::search::QN.swap(0, std::sync::atomic::Ordering::Relaxed));
        let fscore = report_score(res.score);
        if report && res.depth > 0 {
            eprintln!("FoulBroodScore v1;depth={};score={};move={}", res.depth, fscore, text);
            eprintln!(
                "FoulBroodScore v2;kind=final;status=complete;depth={};score={};move={};evalmove={}",
                res.depth, fscore, text, text
            );
        }
        vec![text]
    }
}

fn parse_time(s: &str) -> Option<Duration> {
    let p: Vec<&str> = s.split(':').collect();
    if p.len() != 3 {
        return None;
    }
    let h: u64 = p[0].parse().ok()?;
    let m: u64 = p[1].parse().ok()?;
    let sec: f64 = p[2].parse().ok()?;
    if m >= 60 || sec < 0.0 || sec >= 60.0 {
        return None;
    }
    Some(Duration::from_secs(h * 3600 + m * 60) + Duration::from_secs_f64(sec))
}
