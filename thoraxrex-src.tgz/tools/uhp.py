import subprocess
class Engine:
    def __init__(self, path, args=()):
        self.p = subprocess.Popen([path, *args], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
        self.read()
    def read(self):
        out = []
        while True:
            l = self.p.stdout.readline()
            if l == '':
                raise EOFError('engine died')
            l = l.strip()
            if l == 'ok':
                return out
            out.append(l)
    def cmd(self, c):
        self.p.stdin.write(c + '\n'); self.p.stdin.flush()
        return self.read()
    def close(self):
        try:
            self.p.stdin.write('exit\n'); self.p.stdin.flush()
        except Exception: pass
        self.p.kill()
